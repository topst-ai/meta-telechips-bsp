/**
 * Copyright (C) Arm Limited 2013-2016. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#ifndef DRIVER_H
#define DRIVER_H

#include <stdint.h>

#include "ClassBoilerPlate.h"
#include "mxml/mxml.h"

class Buffer;
class Counter;

class Driver
{
public:
    static Driver *getHead()
    {
        return head;
    }

    virtual ~Driver();

    // Returns true if this driver can manage the counter
    virtual bool claimCounter(Counter &counter) const = 0;

    // Clears and disables all counters
    virtual void resetCounters() = 0;

    // Enables and prepares the counter for capture
    virtual void setupCounter(Counter &counter) = 0;

    // Performs any actions needed for setup or based on eventsXML
    virtual void readEvents(mxml_node_t * const)
    {
    }

    // Emits available counters
    virtual int writeCounters(mxml_node_t * const root) const = 0;

    // Emits possible dynamically generated events/counters
    virtual void writeEvents(mxml_node_t * const) const
    {
    }

    Driver *getNext() const
    {
        return next;
    }

protected:
    Driver();

private:
    static Driver *head;
    Driver *next;

    // Intentionally unimplemented
    CLASS_DELETE_COPY_MOVE(Driver);
};

#endif // DRIVER_H
